package com.example.appdam.entidades

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "Receitas")
data class Receitas(
    @PrimaryKey(autoGenerate = true)
    var id:Int
)

